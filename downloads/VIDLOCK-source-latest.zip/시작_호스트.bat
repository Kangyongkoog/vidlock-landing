@echo off
chcp 65001 >nul
cd /d "%~dp0vidlock-desktop"
echo VIDLOCK 호스트(관리자) 앱 실행 중...
call npm start
pause
