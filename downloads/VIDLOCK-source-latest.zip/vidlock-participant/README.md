# VIDLOCK Participant v1.0.0 (참가자용)

**Zoom 화상회의 실시간 녹화 방지 보안 솔루션 — 참가자용 앱 (무료 배포)**

호스트가 제공하는 참가자용 경량 버전입니다. Zoom 화상회의에 안전하게 참가할 수 있습니다.

© 2026 VIDLOCK (와풀 AI 교육연구소, 강용국). All Rights Reserved.

---

## 빠른 시작 (Quick Start)

```bash
# 1. 의존성 설치
npm install

# 2. 앱 실행
npm start

# 개발 모드 (DevTools 활성화)
npm run dev
```

> **요구 사항:** Node.js 18+ 및 npm 설치 필요

---

## 프로젝트 구조

```
vidlock-participant/
├── src/
│   ├── main.js          # Electron 메인 프로세스 (핵심 로직)
│   ├── preload.js       # contextBridge IPC 브릿지
│   └── index.html       # 렌더러 UI (참가자 인터페이스)
├── build/               # 빌드 리소스 (아이콘, 서명 설정)
│   ├── icon.png / icon.ico / icon.icns
│   ├── tray-icon.png
│   ├── icons/           # 멀티 사이즈 아이콘
│   └── entitlements.mac.plist
├── assets/              # 추가 리소스
├── legal/
│   └── LICENSE_KO.txt
├── package.json
└── README.md            # (이 파일)
```

---

## 주요 기능

| 기능 | 설명 |
|------|------|
| OS 레벨 녹화 차단 | `setContentProtection(true)` — 화면 녹화 시 검은 화면 |
| AI 카메라 감지 | 웹캠으로 핸드폰/카메라 촬영 감지 → 자동 블랙아웃 |
| 포렌식 워터마크 | 참가자 이름/IP/시간 반투명 표시 |
| 녹화 프로세스 감지 | OBS, oCam, 반디캠 등 감지 → 자동 블랙아웃 |
| 위반 경고 | 촬영/녹화 감지 시 법적 경고 표시 |
| PrintScreen 차단 | 화면 캡처 키 차단 |
| Zoom 회의 참가 | VIDLOCK을 통한 안전한 회의 참가 |

---

## 사용 방법

1. 앱 실행
2. 회의 참가 탭에서 Zoom 회의 ID 또는 URL 입력
3. 보호 참가 버튼 클릭
4. 카메라 감지 탭에서 AI 감시 시작 (선택)
5. 영상 보호 탭에서 포렌식 워터마크 이름 설정

---

## IPC 채널명 (preload.js ↔ main.js)

| 채널명 | 방향 | 용도 |
|--------|------|------|
| `open-meeting-inapp` | renderer → main | 회의 열기 |
| `close-meeting-inapp` | renderer → main | 회의 닫기 |
| `hide-meeting-view` | renderer → main | 회의 화면 숨기기 |

---

## 빌드 (배포용 설치 파일 생성)

```bash
# Windows 설치 파일 (.exe)
npm run build:win

# macOS 설치 파일 (.dmg)
npm run build:mac

# Linux 설치 파일 (.AppImage)
npm run build:linux
```

빌드 결과물은 `dist/` 폴더에 생성됩니다.

---

## 호스트용과의 차이

| 기능 | 호스트용 (desktop) | 참가자용 (이 앱) |
|------|---------|---------|
| 회의 생성/예약/관리 | O | X |
| 참가자 모니터링 대시보드 | O | X |
| Zoom 워터마크 설정 가이드 | O | X |
| 회의 참가 | O | O |
| setContentProtection | O | O |
| AI 카메라 감지 | O | O |
| 포렌식 워터마크 | O | O |
| 녹화 프로세스 감지 | O | O |
| 위반 경고 | O | O |

---

## 연락처

- Email: kangyg0612@naver.com
