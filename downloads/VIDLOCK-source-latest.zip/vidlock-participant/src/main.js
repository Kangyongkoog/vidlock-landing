/**
 * ============================================
 * VIDLOCK Participant - Electron Main Process v1.0.0
 * © 2026 VIDLOCK. All Rights Reserved.
 * Patent Pending. Unauthorized use prohibited.
 * ============================================
 * 
 * 참가자용 경량 버전 (무료 배포)
 * - setContentProtection OS 레벨 녹화 차단
 * - 녹화 프로세스 감지 + 자동 블랙아웃
 * - AI 카메라 감지 (핸드폰 촬영 차단)
 * - 포렌식 워터마크 (참가자 이름/IP/시간)
 * - 위반 감지 경고
 * - Zoom 회의 인앱 보호 모드
 * 
 * 호스트용과의 차이:
 * - 회의 생성/예약 기능 없음 (참가만 가능)
 * - Zoom 워터마크 설정 가이드 없음
 * - 설정 최소화 (자동 보호 모드)
 */

const { app, BrowserWindow, BrowserView, Tray, Menu, ipcMain, dialog, screen, nativeImage, session, Notification, clipboard, desktopCapturer } = require('electron');
const path = require('path');
const { execSync, exec } = require('child_process');
const os = require('os');

let mainWindow = null;
let tray = null;
let meetingView = null;
const isDev = process.argv.includes('--dev');

// ===== 녹화 프로세스 감지 =====
const RECORDER_PROCESSES = [
  'obs64.exe','obs32.exe','obs.exe','streamlabs obs.exe',
  'ocam.exe','bandicam.exe','bdcam.exe','camtasia.exe',
  'camrecorder.exe','snagit32.exe','snagit.exe',
  'screenrec.exe','screenpresso.exe','sharex.exe',
  'action.exe','fraps.exe','xsplit.core.exe',
  'xsplitbroadcaster.exe','xsplitgamecaster.exe',
  'movavi screen recorder.exe','loom.exe',
  'screencastify.exe','vokoscreenng.exe',
  'kazam','simplescreenrecorder','recordmydesktop',
  'ffmpeg','vlc','peek'
];

function detectRecordingProcesses() {
  try {
    const platform = process.platform;
    let output = '';
    if (platform === 'win32') {
      output = execSync('tasklist /FO CSV /NH', { encoding: 'utf-8', timeout: 5000 });
    } else if (platform === 'darwin') {
      output = execSync('ps -eo comm', { encoding: 'utf-8', timeout: 5000 });
    } else {
      output = execSync('ps -eo comm', { encoding: 'utf-8', timeout: 5000 });
    }
    const lower = output.toLowerCase();
    return RECORDER_PROCESSES.filter(p => lower.includes(p.toLowerCase()));
  } catch (e) { return []; }
}

// ===== 앱 시작 =====
app.whenReady().then(() => {
  // 메인 윈도우 생성
  const { width, height } = screen.getPrimaryDisplay().workAreaSize;
  mainWindow = new BrowserWindow({
    width: width,
    height: height,
    minWidth: 900,
    minHeight: 600,
    title: 'VIDLOCK Participant',
    icon: path.join(__dirname, '..', 'build', 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    },
    show: false
  });

  // setContentProtection - OS 레벨 녹화 차단
  mainWindow.setContentProtection(true);
  
  // 최대화 상태로 시작
  mainWindow.maximize();
  mainWindow.show();

  mainWindow.loadFile(path.join(__dirname, 'index.html'));

  // ===== 한국어 메뉴바 =====
  const menuTemplate = [
    {
      label: '파일',
      submenu: [
        { label: '새로고침', accelerator: 'CmdOrCtrl+R', click: () => mainWindow.reload() },
        { type: 'separator' },
        { label: '종료', accelerator: 'CmdOrCtrl+Q', click: () => app.quit() }
      ]
    },
    {
      label: '보기',
      submenu: [
        { label: '전체 화면', accelerator: 'F11', click: () => mainWindow.setFullScreen(!mainWindow.isFullScreen()) },
        { label: '확대', accelerator: 'CmdOrCtrl+Plus', role: 'zoomIn' },
        { label: '축소', accelerator: 'CmdOrCtrl+-', role: 'zoomOut' },
        { label: '원래 크기', accelerator: 'CmdOrCtrl+0', role: 'resetZoom' },
        ...(isDev ? [{ type: 'separator' }, { label: '개발자 도구', accelerator: 'F12', click: () => mainWindow.webContents.toggleDevTools() }] : [])
      ]
    },
    {
      label: '창',
      submenu: [
        { label: '최소화', role: 'minimize' },
        { label: '최대화', click: () => mainWindow.isMaximized() ? mainWindow.unmaximize() : mainWindow.maximize() },
        { label: '닫기', accelerator: 'CmdOrCtrl+W', click: () => mainWindow.close() }
      ]
    },
    {
      label: '도움말',
      submenu: [
        {
          label: 'VIDLOCK Participant 정보',
          click: () => {
            dialog.showMessageBox({
              type: 'info',
              title: 'VIDLOCK Participant',
              message: 'VIDLOCK Participant v1.0.0',
              detail: '© 2026 VIDLOCK. All Rights Reserved.\n특허 출원 중 | 상표 등록 출원 중\n\n참가자용 Zoom 화상회의 녹화 방지 솔루션\n• setContentProtection OS 레벨 차단\n• AI 웹캠 카메라 감지\n• 포렌식 워터마크 (법적 증거)\n• 녹화 프로세스 감지 + 자동 블랙아웃\n• 위반 감지 경고 시스템\n\n이 앱은 호스트가 제공한 무료 참가자용 버전입니다.'
            });
          }
        }
      ]
    }
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(menuTemplate));

  // ===== 트레이 아이콘 =====
  try {
    const trayIconPath = path.join(__dirname, '..', 'build', 'tray-icon.png');
    const trayIcon = nativeImage.createFromPath(trayIconPath).resize({ width: 16, height: 16 });
    tray = new Tray(trayIcon);
    tray.setToolTip('VIDLOCK Participant - 보호 활성화');
    tray.setContextMenu(Menu.buildFromTemplate([
      { label: '🛡️ VIDLOCK Participant', enabled: false },
      { label: '보호 상태: 활성화', enabled: false },
      { type: 'separator' },
      { label: '창 보이기', click: () => { mainWindow.show(); mainWindow.focus(); } },
      { type: 'separator' },
      { label: '종료', click: () => app.quit() }
    ]));
    tray.on('click', () => { mainWindow.show(); mainWindow.focus(); });
  } catch (e) {}

  // ===== IPC 핸들러 =====
  
  // 보호 상태
  ipcMain.handle('get-protection-status', () => {
    return { contentProtection: true, platform: process.platform, isParticipant: true };
  });

  // 앱 정보
  ipcMain.handle('get-app-info', () => ({
    version: '1.0.0',
    electron: process.versions.electron,
    chrome: process.versions.chrome,
    node: process.versions.node,
    platform: process.platform,
    arch: process.arch,
    isParticipant: true
  }));

  // 알림
  ipcMain.handle('show-notification', (e, { title, body }) => {
    new Notification({ title, body, icon: path.join(__dirname, '..', 'build', 'icon.png') }).show();
  });

  // 클립보드 비우기
  ipcMain.handle('clear-clipboard', () => { clipboard.clear(); });

  // IP 주소
  ipcMain.handle('get-local-ip', () => {
    const interfaces = os.networkInterfaces();
    for (const name of Object.keys(interfaces)) {
      for (const iface of interfaces[name]) {
        if (iface.family === 'IPv4' && !iface.internal) return iface.address;
      }
    }
    return '127.0.0.1';
  });

  // 녹화 프로세스 감지
  ipcMain.handle('check-recording-processes', () => detectRecordingProcesses());

  // 녹화 프로세스 종료
  ipcMain.handle('kill-recording-process', (e, name) => {
    try {
      if (process.platform === 'win32') {
        execSync(`taskkill /F /IM "${name}"`, { timeout: 5000 });
      } else {
        execSync(`pkill -f "${name}"`, { timeout: 5000 });
      }
      return true;
    } catch (e) { return false; }
  });

  // ===== Zoom 인앱 회의 참가 =====
  ipcMain.handle('open-meeting-inapp', (e, url) => {
    openMeetingInApp(url);
  });

  ipcMain.handle('close-meeting-inapp', () => {
    if (meetingView) {
      mainWindow.removeBrowserView(meetingView);
      meetingView.webContents.destroy();
      meetingView = null;
      mainWindow.webContents.send('meeting-closed');
    }
  });

  ipcMain.handle('is-meeting-open', () => !!meetingView);

  ipcMain.handle('show-meeting-view', () => {
    if (meetingView) updateMeetingViewBounds();
  });

  ipcMain.handle('hide-meeting-view', () => {
    if (meetingView) meetingView.setBounds({ x: 0, y: 0, width: 0, height: 0 });
  });

  // ===== 녹화 프로세스 주기적 감시 (3초) =====
  setInterval(() => {
    const found = detectRecordingProcesses();
    if (found.length > 0 && mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('recording-detected', found);
    }
    if (found.length === 0 && mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('recording-cleared');
    }
  }, 3000);

  // 닫기 시 트레이로 최소화
  mainWindow.on('close', (e) => {
    if (!app.isQuitting) {
      e.preventDefault();
      mainWindow.hide();
    }
  });
});

// ===== Zoom 인앱 회의 =====
function isMeetingURL(url) {
  return url && (url.includes('zoom.us') || url.includes('zoom.com'));
}

function updateMeetingViewBounds() {
  if (!meetingView || !mainWindow) return;
  const bounds = mainWindow.getContentBounds();
  const sidebarWidth = 56;
  const headerHeight = 48;
  meetingView.setBounds({
    x: sidebarWidth,
    y: headerHeight,
    width: bounds.width - sidebarWidth,
    height: bounds.height - headerHeight
  });
}

function openMeetingInApp(url) {
  if (meetingView) {
    mainWindow.removeBrowserView(meetingView);
    meetingView.webContents.destroy();
    meetingView = null;
  }

  meetingView = new BrowserView({
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });

  mainWindow.addBrowserView(meetingView);
  updateMeetingViewBounds();
  mainWindow.on('resize', updateMeetingViewBounds);

  // setContentProtection을 BrowserView에도 적용
  meetingView.webContents.on('did-finish-load', () => {
    mainWindow.setContentProtection(true);
  });

  // 권한 요청 자동 허용 (마이크, 카메라)
  meetingView.webContents.session.setPermissionRequestHandler((webContents, permission, callback) => {
    const allowed = ['media', 'microphone', 'camera', 'display-capture', 'audioCapture', 'videoCapture', 'notifications'];
    callback(allowed.includes(permission));
  });

  // 화면 공유 지원 - 다중 모니터 선택
  meetingView.webContents.session.setDisplayMediaRequestHandler(async (request, callback) => {
    try {
      const sources = await desktopCapturer.getSources({ 
        types: ['screen', 'window'],
        thumbnailSize: { width: 320, height: 180 }
      });
      
      if (sources.length === 0) { callback({}); return; }
      
      const screens = sources.filter(s => s.id.startsWith('screen:'));
      const windows = sources.filter(s => s.id.startsWith('window:'));
      
      if (screens.length <= 1 && windows.length === 0) {
        callback({ video: screens[0] || sources[0], audio: 'loopback' });
        return;
      }
      
      const allSources = [];
      const sourceNames = [];
      
      screens.forEach((s, idx) => {
        allSources.push(s);
        const displayNum = idx + 1;
        const displayInfo = screen.getAllDisplays()[idx];
        const resolution = displayInfo ? `${displayInfo.size.width}x${displayInfo.size.height}` : '';
        sourceNames.push(`📺 모니터 ${displayNum} ${resolution ? '(' + resolution + ')' : ''}: ${s.name}`);
      });
      
      const topWindows = windows.slice(0, 10);
      topWindows.forEach(s => {
        allSources.push(s);
        sourceNames.push(`🗗️ 창: ${s.name.substring(0, 40)}`);
      });
      
      const { response } = await dialog.showMessageBox(mainWindow, {
        type: 'question',
        title: '화면 공유 선택',
        message: `공유할 화면을 선택하세요 (모니터 ${screens.length}개 감지):`,
        buttons: [...sourceNames, '취소'],
        defaultId: 0,
        cancelId: sourceNames.length
      });
      
      if (response < allSources.length) {
        callback({ video: allSources[response], audio: 'loopback' });
      } else { callback({}); }
    } catch (e) {
      try {
        const sources = await desktopCapturer.getSources({ types: ['screen'] });
        if (sources.length > 0) callback({ video: sources[0], audio: 'loopback' });
        else callback({});
      } catch(e2) { callback({}); }
    }
  });

  // URL 로드
  meetingView.webContents.loadURL(url, {
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'
  });

  // 새 창 열기 → 같은 뷰에서 네비게이션
  meetingView.webContents.setWindowOpenHandler(({ url: popupUrl }) => {
    if (isMeetingURL(popupUrl) || popupUrl.includes('oauth') || popupUrl.includes('login') || popupUrl.includes('signin')) {
      meetingView.webContents.loadURL(popupUrl);
    }
    return { action: 'deny' };
  });

  mainWindow.webContents.send('meeting-opened', url);
}

app.on('before-quit', () => { app.isQuitting = true; });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
