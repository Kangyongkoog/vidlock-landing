/**
 * VIDLOCK Participant - Preload Script v1.0.0
 * 참가자용 경량 버전 IPC 브릿지
 */
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('vidlock', {
  // 보호 상태
  getProtectionStatus: () => ipcRenderer.invoke('get-protection-status'),
  getAppInfo: () => ipcRenderer.invoke('get-app-info'),
  
  // 알림
  showNotification: (data) => ipcRenderer.invoke('show-notification', data),
  
  // 클립보드
  clearClipboard: () => ipcRenderer.invoke('clear-clipboard'),
  
  // IP 주소
  getLocalIP: () => ipcRenderer.invoke('get-local-ip'),
  
  // 녹화 프로세스
  checkRecordingProcesses: () => ipcRenderer.invoke('check-recording-processes'),
  killRecordingProcess: (name) => ipcRenderer.invoke('kill-recording-process', name),
  
  // 녹화 감지 이벤트
  onRecordingDetected: (cb) => ipcRenderer.on('recording-detected', (e, data) => cb(data)),
  onRecordingCleared: (cb) => ipcRenderer.on('recording-cleared', () => cb()),
  
  // 회의 인앱 모드
  openMeetingInApp: (url) => ipcRenderer.invoke('open-meeting-inapp', url),
  closeMeetingInApp: () => ipcRenderer.invoke('close-meeting-inapp'),
  isMeetingOpen: () => ipcRenderer.invoke('is-meeting-open'),
  showMeetingView: () => ipcRenderer.invoke('show-meeting-view'),
  hideMeetingView: () => ipcRenderer.invoke('hide-meeting-view'),
  onMeetingOpened: (cb) => ipcRenderer.on('meeting-opened', (e, url) => cb(url)),
  onMeetingClosed: (cb) => ipcRenderer.on('meeting-closed', () => cb()),
  
  // 블랙아웃
  onBlackout: (cb) => ipcRenderer.on('blackout', (e, data) => cb(data)),
  
  // 플랫폼 정보
  isElectron: true,
  platform: process.platform
});
