@echo off
chcp 65001 >nul
cd /d "%~dp0vidlock-participant"
echo VIDLOCK 참가자 앱 실행 중...
call npm start
pause
