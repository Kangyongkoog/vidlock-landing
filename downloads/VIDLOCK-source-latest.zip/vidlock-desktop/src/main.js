/**
 * ============================================
 * VIDLOCK Desktop - Electron Main Process v1.6.1
 * © 2026 VIDLOCK. All Rights Reserved.
 * Patent Pending. Unauthorized use prohibited.
 * ============================================
 * 
 * 핵심 기술:
 * 1. setContentProtection(true) → OS 레벨 화면 녹화/스크린샷 차단
 * 2. Zoom 전용 화상회의 보호 모드
 * 3. 시스템 트레이 상주 → 항시 보호
 * 4. 녹화 프로세스 능동 감지 + 자동 블랙아웃
 * 5. [v1.3.0] Zoom을 메인 창 내부 BrowserView로 임베딩 (인앱 회의)
 * 6. [v1.3.0] desktopCapturer 연동 → 화면 공유 지원
 * 7. [v1.4.0] 메뉴바 한국어화 + 창 최대화 시작 + 녹화 감지 블랙아웃 강화
 * 8. [v1.5.0] 포렌식 워터마크 + 위반 감지 경고
 * 9. [v1.5.1] 다중 모니터 화면 공유 선택 UI + 공유화면 보기 자동 전환
 * 10. [v1.6.0] Zoom 전용으로 정리 + Zoom 워터마크 연동 안내
 * 11. [v1.6.1] 공유화면 크게 보기 개선 + 다중모니터 공유 개선 + 경고문구 개선
 */

const { app, BrowserWindow, BrowserView, Tray, Menu, ipcMain, dialog, screen, nativeImage, session, Notification, clipboard, desktopCapturer } = require('electron');
const path = require('path');
const { execSync } = require('child_process');

// ---- 싱글 인스턴스 강제 (중복 실행 방지) ----
const gotTheLock = app.requestSingleInstanceLock();
if (!gotTheLock) {
  app.quit();
  process.exit(0);
}

let mainWindow = null;
let meetingView = null; // [v1.3.0] 메인 창 내부 BrowserView
let tray = null;
let isContentProtected = true;
let recordingCheckInterval = null;
const isDevMode = process.argv.includes('--dev');

// ============================================
// 화상회의 도메인 화이트리스트
// ============================================
const MEETING_DOMAINS = [
  'zoom.us', 'zoom.com'
];

function isMeetingURL(url) {
  try {
    const hostname = new URL(url).hostname;
    return MEETING_DOMAINS.some(domain => hostname === domain || hostname.endsWith('.' + domain));
  } catch (e) {
    return false;
  }
}

// ============================================
// [v1.4.0] 한국어 메뉴바 생성
// ============================================

function createKoreanMenu() {
  const template = [
    {
      label: '파일',
      submenu: [
        {
          label: '새로고침',
          accelerator: 'CmdOrCtrl+R',
          click: () => {
            if (mainWindow) mainWindow.webContents.reload();
          }
        },
        { type: 'separator' },
        {
          label: '종료',
          accelerator: process.platform === 'darwin' ? 'Cmd+Q' : 'Alt+F4',
          click: () => {
            app.isQuitting = true;
            if (meetingView) closeMeetingInApp();
            app.quit();
          }
        }
      ]
    },
    {
      label: '편집',
      submenu: [
        { label: '실행 취소', accelerator: 'CmdOrCtrl+Z', role: 'undo' },
        { label: '다시 실행', accelerator: 'CmdOrCtrl+Shift+Z', role: 'redo' },
        { type: 'separator' },
        { label: '잘라내기', accelerator: 'CmdOrCtrl+X', role: 'cut' },
        { label: '복사', accelerator: 'CmdOrCtrl+C', role: 'copy' },
        { label: '붙여넣기', accelerator: 'CmdOrCtrl+V', role: 'paste' },
        { label: '전체 선택', accelerator: 'CmdOrCtrl+A', role: 'selectAll' }
      ]
    },
    {
      label: '보기',
      submenu: [
        {
          label: '전체 화면',
          accelerator: 'F11',
          click: () => {
            if (mainWindow) {
              mainWindow.setFullScreen(!mainWindow.isFullScreen());
            }
          }
        },
        {
          label: '확대',
          accelerator: 'CmdOrCtrl+=',
          role: 'zoomIn'
        },
        {
          label: '축소',
          accelerator: 'CmdOrCtrl+-',
          role: 'zoomOut'
        },
        {
          label: '원래 크기',
          accelerator: 'CmdOrCtrl+0',
          role: 'resetZoom'
        },
        ...(isDevMode ? [
          { type: 'separator' },
          {
            label: '개발자 도구',
            accelerator: 'F12',
            click: () => {
              if (mainWindow) mainWindow.webContents.toggleDevTools();
            }
          }
        ] : [])
      ]
    },
    {
      label: '창',
      submenu: [
        {
          label: '최소화',
          accelerator: 'CmdOrCtrl+M',
          role: 'minimize'
        },
        {
          label: '최대화',
          click: () => {
            if (mainWindow) {
              if (mainWindow.isMaximized()) {
                mainWindow.unmaximize();
              } else {
                mainWindow.maximize();
              }
            }
          }
        },
        { type: 'separator' },
        {
          label: '닫기',
          accelerator: 'CmdOrCtrl+W',
          click: () => {
            if (mainWindow) mainWindow.close();
          }
        }
      ]
    },
    {
      label: '도움말',
      submenu: [
        {
          label: 'VIDLOCK 정보',
          click: () => {
            dialog.showMessageBox({
              type: 'info',
              title: 'VIDLOCK Desktop',
              message: 'VIDLOCK Desktop v1.6.1',
              detail: '© 2026 VIDLOCK. All Rights Reserved.\n특허 출원 중 | 상표 등록 출원 중\n\nAI 기반 Zoom 화상회의 녹화 방지 솔루션\n• setContentProtection OS 레벨 차단\n• Zoom 전용 인앱 보호 모드\n• Zoom 워터마크 연동 (상대방 녹화 추적)\n• AI 웹캠 카메라 감지\n• 포렌식 워터마크 (법적 증거)\n• 녹화 프로세스 감지 + 자동 블랙아웃\n• 위반 감지 경고 시스템'
            });
          }
        },
        {
          label: '버전 확인',
          click: () => {
            dialog.showMessageBox({
              type: 'info',
              title: '버전 정보',
              message: `VIDLOCK Desktop v${app.getVersion()}`,
              detail: `Electron: ${process.versions.electron}\nChrome: ${process.versions.chrome}\nNode.js: ${process.versions.node}\n플랫폼: ${process.platform} (${process.arch})\n개발자 모드: ${isDevMode ? '활성화' : '비활성화'}`
            });
          }
        }
      ]
    }
  ];

  // macOS에서는 첫 번째 메뉴가 앱 이름
  if (process.platform === 'darwin') {
    template.unshift({
      label: app.getName(),
      submenu: [
        { label: 'VIDLOCK 정보', role: 'about' },
        { type: 'separator' },
        { label: '서비스', role: 'services' },
        { type: 'separator' },
        { label: 'VIDLOCK 숨기기', accelerator: 'Cmd+H', role: 'hide' },
        { label: '다른 앱 숨기기', accelerator: 'Cmd+Alt+H', role: 'hideOthers' },
        { label: '모두 보이기', role: 'unhide' },
        { type: 'separator' },
        {
          label: '종료',
          accelerator: 'Cmd+Q',
          click: () => {
            app.isQuitting = true;
            if (meetingView) closeMeetingInApp();
            app.quit();
          }
        }
      ]
    });
  }

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
}

// ============================================
// 1. 메인 윈도우 생성
// ============================================

function createMainWindow() {
  const { width, height } = screen.getPrimaryDisplay().workAreaSize;

  mainWindow = new BrowserWindow({
    width: Math.min(1400, width - 100),
    height: Math.min(900, height - 100),
    minWidth: 900,
    minHeight: 600,
    title: 'VIDLOCK Desktop',
    icon: path.join(__dirname, '../build/icon.png'),
    
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: false,
      webSecurity: true,
      webviewTag: true // [v1.3.0] webview 태그 허용
    },

    backgroundColor: '#0a0e17',
    titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default',
    frame: true,
    show: false,
  });

  // ============================================
  // 핵심: OS 레벨 화면 녹화 차단
  // ============================================
  mainWindow.setContentProtection(true);

  // ---- 카메라/마이크/화면공유 권한 자동 허용 ----
  session.defaultSession.setPermissionRequestHandler((webContents, permission, callback) => {
    const allowedPermissions = ['media', 'mediaKeySystem', 'notifications', 'audioCapture', 'videoCapture', 'display-capture', 'screen'];
    if (allowedPermissions.includes(permission)) {
      callback(true);
    } else {
      callback(false);
    }
  });

  // [v1.3.0] 화면 공유를 위한 desktopCapturer 연동
  session.defaultSession.setDisplayMediaRequestHandler((request, callback) => {
    desktopCapturer.getSources({ types: ['screen', 'window'] }).then((sources) => {
      if (sources.length > 0) {
        callback({ video: sources[0], audio: 'loopback' });
      } else {
        callback({});
      }
    }).catch(() => {
      callback({});
    });
  });

  // ---- 앱 로드 ----
  mainWindow.loadFile(path.join(__dirname, 'index.html'));

  // ---- [v1.4.0] Ready to show → 최대화 상태로 표시 ----
  mainWindow.once('ready-to-show', () => {
    mainWindow.maximize(); // [v1.4.0] 창 최대화로 시작
    mainWindow.show();
    mainWindow.focus();
  });

  // ---- 창 닫기 → 트레이로 최소화 ----
  mainWindow.on('close', (event) => {
    if (!app.isQuitting) {
      event.preventDefault();
      mainWindow.hide();
      showCrossPlatformNotification('VIDLOCK', '보호가 계속 실행 중입니다. 트레이에서 복원하세요.');
    }
  });

  mainWindow.on('closed', () => { mainWindow = null; });

  // ---- 창 크기 변경 시 BrowserView 리사이즈 ----
  mainWindow.on('resize', () => {
    updateMeetingViewBounds();
  });

  // ---- 개발자 도구 차단 (프로덕션) ----
  if (!isDevMode) {
    mainWindow.webContents.on('before-input-event', (event, input) => {
      if (input.key === 'F12' || 
          (input.control && input.shift && (input.key === 'I' || input.key === 'J')) ||
          (input.control && input.key === 'u')) {
        event.preventDefault();
      }
    });
  }
}

// ============================================
// 1-1. 크로스플랫폼 알림 헬퍼
// ============================================
function showCrossPlatformNotification(title, body) {
  if (Notification.isSupported()) {
    const notification = new Notification({ title, body, icon: path.join(__dirname, '../build/icon.png') });
    notification.show();
  } else if (tray && process.platform === 'win32') {
    tray.displayBalloon({ title, content: body, iconType: 'info' });
  }
}

// ============================================
// 1-2. [v1.3.0] 인앱 회의 BrowserView 관리
// ============================================

function updateMeetingViewBounds() {
  if (!meetingView || !mainWindow) return;
  const bounds = mainWindow.getContentBounds();
  // [v1.3.1] 전체 창 크기로 확장
  meetingView.setBounds({
    x: 0,
    y: 0,
    width: bounds.width,
    height: bounds.height
  });
}

function openMeetingInApp(url) {
  if (!mainWindow) return;

  // 기존 회의 뷰가 있으면 제거
  if (meetingView) {
    mainWindow.removeBrowserView(meetingView);
    meetingView.webContents.destroy();
    meetingView = null;
  }

  meetingView = new BrowserView({
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: false,
      webSecurity: true,
      allowRunningInsecureContent: false
    }
  });

  mainWindow.addBrowserView(meetingView);
  updateMeetingViewBounds();

  // 카메라/마이크/화면공유 권한 자동 허용 (회의 뷰)
  meetingView.webContents.session.setPermissionRequestHandler((webContents, permission, callback) => {
    const allowedPermissions = ['media', 'mediaKeySystem', 'notifications', 'audioCapture', 'videoCapture', 'display-capture', 'screen'];
    if (allowedPermissions.includes(permission)) {
      callback(true);
    } else {
      callback(false);
    }
  });

  // [v1.6.1] 화면 공유 지원 - 다중 모니터 선택 UI 개선
  meetingView.webContents.session.setDisplayMediaRequestHandler(async (request, callback) => {
    try {
      const sources = await desktopCapturer.getSources({ 
        types: ['screen', 'window'],
        thumbnailSize: { width: 320, height: 180 }
      });
      
      if (sources.length === 0) {
        callback({});
        return;
      }
      
      // 모니터(screen)와 창(window) 분리
      const screens = sources.filter(s => s.id.startsWith('screen:'));
      const windows = sources.filter(s => s.id.startsWith('window:'));
      
      // 모니터 1개이고 창도 없으면 바로 공유
      if (screens.length <= 1 && windows.length === 0) {
        callback({ video: screens[0] || sources[0], audio: 'loopback' });
        return;
      }
      
      // 선택 목록 구성
      const allSources = [];
      const sourceNames = [];
      
      // 모니터 목록 (번호 정확하게)
      screens.forEach((s, idx) => {
        allSources.push(s);
        const displayNum = idx + 1;
        const displayInfo = screen.getAllDisplays()[idx];
        const resolution = displayInfo ? `${displayInfo.size.width}x${displayInfo.size.height}` : '';
        sourceNames.push(`📺 모니터 ${displayNum} ${resolution ? '(' + resolution + ')' : ''}: ${s.name}`);
      });
      
      // 주요 창 목록 (상위 10개만)
      const topWindows = windows.slice(0, 10);
      topWindows.forEach(s => {
        allSources.push(s);
        sourceNames.push(`🗗️ 창: ${s.name.substring(0, 40)}`);
      });
      
      // Electron dialog로 선택 UI 표시
      const { response } = await dialog.showMessageBox(mainWindow, {
        type: 'question',
        title: '화면 공유 선택',
        message: `공유할 화면을 선택하세요 (모니터 ${screens.length}개 감지):`,
        buttons: [...sourceNames, '취소'],
        defaultId: 0,
        cancelId: sourceNames.length
      });
      
      if (response < allSources.length) {
        callback({ video: allSources[response], audio: 'loopback' });
      } else {
        callback({});
      }
    } catch (e) {
      // 에러 시 첫 번째 소스로 fallback
      try {
        const sources = await desktopCapturer.getSources({ types: ['screen'] });
        if (sources.length > 0) callback({ video: sources[0], audio: 'loopback' });
        else callback({});
      } catch(e2) { callback({}); }
    }
  });

  // 일반 Chrome User-Agent로 로드
  meetingView.webContents.loadURL(url, {
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'
  });

  // [v1.6.1] Zoom 웹 화면 공유 보기 최적화 - 공유 화면이 크게 보이도록 (3단계 접근)
  const injectShareScreenOptimizer = () => {
    if (!meetingView) return;

    // [v1.6.1] 3단계 접근: 1) 더블클릭 전체화면 2) View 버튼 클릭 3) CSS 강제 주입
    meetingView.webContents.executeJavaScript(`
      (function() {
        let lastShareState = false;
        let shareViewSwitched = false;

        // === 1단계: Zoom 웹의 "보기/View" 버튼 클릭 후 Standard/표준 선택 ===
        function tryClickViewStandard() {
          // 보기/View 버튼 찾기 - Zoom 웹의 우측 상단
          const allEls = document.querySelectorAll('button, [role="button"], span, div');
          for (const el of allEls) {
            const text = (el.textContent || '').trim();
            const label = (el.getAttribute('aria-label') || '').trim();
            // "보기" 또는 "View" 버튼 (정확한 매치)
            if ((text === '보기' || text === 'View') && el.offsetParent !== null) {
              console.log('[VIDLOCK] View 버튼 발견:', text);
              el.click();
              // 드롭다운 메뉴 나타날 때까지 대기
              setTimeout(() => {
                const items = document.querySelectorAll('[role="menuitem"], [role="option"], [role="menuitemradio"], li[role], div[role="option"]');
                for (const item of items) {
                  const t = (item.textContent || '').trim().toLowerCase();
                  if (t.includes('standard') || t.includes('표준') || t === 'standard') {
                    console.log('[VIDLOCK] Standard 보기 선택:', t);
                    item.click();
                    shareViewSwitched = true;
                    return;
                  }
                }
                // Standard 못 찾으면 첫 번째 메뉴 아이템 클릭 (보통 Standard)
                if (items.length > 0) {
                  console.log('[VIDLOCK] 첫 번째 메뉴 아이템 선택:', items[0].textContent);
                  items[0].click();
                  shareViewSwitched = true;
                }
              }, 1000);
              return true;
            }
          }
          return false;
        }

        // === 2단계: 더블클릭으로 Zoom 전체화면 전환 ===
        function tryDoubleClickFullscreen() {
          // Zoom 웹의 메인 영역을 더블클릭하면 전체화면으로 전환됨
          const mainArea = document.querySelector('[class*="meeting"]') || 
                          document.querySelector('[class*="video"]') || 
                          document.querySelector('canvas') ||
                          document.querySelector('[id*="video"]') ||
                          document.body;
          if (mainArea) {
            const dblClick = new MouseEvent('dblclick', { bubbles: true, cancelable: true });
            mainArea.dispatchEvent(dblClick);
            console.log('[VIDLOCK] 더블클릭 전체화면 시도');
          }
        }

        // === 3단계: CSS 강제 주입 - 공유화면 크게, 비디오 작게 ===
        function injectShareCSS() {
          if (document.getElementById('vidlock-share-css')) return;
          const style = document.createElement('style');
          style.id = 'vidlock-share-css';
          style.textContent = [
            // 공유 화면 캔버스/비디오를 최대 크기로
            '[class*="sharee"] canvas, [class*="share"][class*="content"] canvas, [id*="sharee"] canvas { width:100%!important; height:100%!important; object-fit:contain!important; }',
            '[class*="sharee"], [class*="share-content"], [id*="sharee-container"] { width:100%!important; height:100%!important; position:absolute!important; inset:0!important; z-index:1!important; }',
            // 참가자 비디오를 작은 PIP로
            '[class*="speaker"][class*="active"] video, [class*="avatar"][class*="active"] { max-width:200px!important; max-height:150px!important; position:fixed!important; bottom:10px!important; right:10px!important; z-index:10!important; border-radius:8px!important; }',
            // 공유 화면 영역 최대화
            '[class*="sharee"][class*="wrap"], [class*="share"][class*="view"] { flex:1!important; width:100%!important; height:100%!important; }'
          ].join('\n');
          document.head.appendChild(style);
          console.log('[VIDLOCK] 공유화면 CSS 강제 주입');
        }

        function checkShareScreen() {
          // 화면 공유 중인지 감지 (다양한 지표)
          const shareIndicators = [
            '[class*="share"][class*="bar"]',
            '[class*="sharing"][class*="indicator"]',
            '[class*="screen-share"]',
            '[aria-label*="화면 공유"]',
            '[aria-label*="Screen Share"]',
            '[aria-label*="sharing"]',
            'button[aria-label*="공유 중지"]',
            'button[aria-label*="Stop Share"]',
            '[class*="sharee"]',
            '#sharee-container'
          ];

          let isSharing = false;
          for (const sel of shareIndicators) {
            if (document.querySelector(sel)) {
              isSharing = true;
              break;
            }
          }

          // 화면 공유 시작 감지
          if (isSharing && !lastShareState) {
            lastShareState = true;
            shareViewSwitched = false;
            console.log('[VIDLOCK] 화면 공유 감지 - 3단계 보기 전환 시도');
            
            // 1단계: View 버튼 클릭 (1.5초 후)
            setTimeout(() => {
              tryClickViewStandard();
            }, 1500);
            
            // 2단계: 더블클릭 전체화면 (3초 후)
            setTimeout(() => {
              if (!shareViewSwitched) tryDoubleClickFullscreen();
            }, 3000);
            
            // 3단계: CSS 강제 주입 (2초 후)
            setTimeout(() => {
              injectShareCSS();
            }, 2000);
            
            // 재시도: 5초 후 한 번 더
            setTimeout(() => {
              if (!shareViewSwitched) {
                tryClickViewStandard();
                setTimeout(() => {
                  if (!shareViewSwitched) tryDoubleClickFullscreen();
                }, 1500);
              }
            }, 5000);
          }

          if (!isSharing && lastShareState) {
            lastShareState = false;
            shareViewSwitched = false;
            // CSS 제거
            const css = document.getElementById('vidlock-share-css');
            if (css) css.remove();
            console.log('[VIDLOCK] 화면 공유 종료 - CSS 제거');
          }
        }

        // 2초마다 화면 공유 상태 체크 (더 빠르게)
        setInterval(checkShareScreen, 2000);

        console.log('[VIDLOCK v1.6.1] 화면 공유 보기 최적화 3단계 스크립트 로드');
      })();
    `).catch(() => {});
  };

  meetingView.webContents.on('did-finish-load', injectShareScreenOptimizer);
  meetingView.webContents.on('did-navigate-in-page', injectShareScreenOptimizer);

  // 회의 뷰 내부에서 새 창 열기 → 같은 뷰에서 네비게이션
  meetingView.webContents.setWindowOpenHandler(({ url: popupUrl }) => {
    if (isMeetingURL(popupUrl) || popupUrl.includes('oauth') || popupUrl.includes('login') || popupUrl.includes('signin') || popupUrl.includes('accounts.google')) {
      meetingView.webContents.loadURL(popupUrl);
      return { action: 'deny' };
    }
    require('electron').shell.openExternal(popupUrl);
    return { action: 'deny' };
  });

  // 메인 창에 알림
  if (mainWindow) {
    mainWindow.webContents.send('meeting-opened', url);
  }

  return true;
}

function closeMeetingInApp() {
  if (!meetingView || !mainWindow) return;
  mainWindow.removeBrowserView(meetingView);
  meetingView.webContents.destroy();
  meetingView = null;
  if (mainWindow) {
    mainWindow.webContents.send('meeting-closed');
  }
}

// ============================================
// 2. 시스템 트레이
// ============================================

function createTray() {
  if (tray) {
    tray.destroy();
    tray = null;
  }

  let trayIcon;
  const iconPath = path.join(__dirname, '../build/tray-icon.png');
  try {
    trayIcon = nativeImage.createFromPath(iconPath);
    if (trayIcon.isEmpty()) throw new Error('Empty icon');
  } catch (e) {
    trayIcon = nativeImage.createFromDataURL(
      'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAADklEQVQ4jWNgGAWDEwAAAhAAAbkJmYkAAAAASUVORK5CYII='
    );
  }

  tray = new Tray(trayIcon);

  const contextMenu = Menu.buildFromTemplate([
    { 
      label: '🛡️ VIDLOCK 열기', 
      click: () => { 
        if (mainWindow) { mainWindow.show(); mainWindow.focus(); } 
      } 
    },
    { type: 'separator' },
    {
      label: isContentProtected ? '🔒 화면 보호: ON' : '🔓 화면 보호: OFF',
      click: () => {
        isContentProtected = !isContentProtected;
        if (mainWindow) {
          mainWindow.setContentProtection(isContentProtected);
          mainWindow.webContents.send('protection-changed', isContentProtected);
        }
        createTray();
      }
    },
    { type: 'separator' },
    { 
      label: '⚙️ 설정', 
      click: () => {
        if (mainWindow) { mainWindow.show(); mainWindow.focus(); }
      }
    },
    { 
      label: '📋 정보',
      click: () => {
        dialog.showMessageBox({
          type: 'info',
          title: 'VIDLOCK Desktop',
          message: 'VIDLOCK Desktop v1.6.1',
          detail: '© 2026 VIDLOCK. All Rights Reserved.\n특허 출원 중 | 상표 등록 출원 중\n\nAI 기반 Zoom 화상회의 녹화 방지 솔루션\n• setContentProtection OS 레벨 차단\n• Zoom 전용 인앱 보호 모드\n• Zoom 워터마크 연동 (상대방 녹화 추적)\n• AI 웹캠 카메라 감지\n• 포렌식 워터마크 (법적 증거)\n• 녹화 프로세스 감지 + 자동 블랙아웃\n• 위반 감지 경고 시스템'
        });
      }
    },
    { type: 'separator' },
    { 
      label: '❌ 종료', 
      click: () => { 
        app.isQuitting = true; 
        if (meetingView) closeMeetingInApp();
        app.quit(); 
      } 
    }
  ]);

  tray.setToolTip('VIDLOCK - 영상 녹화 방지 보호 중');
  tray.setContextMenu(contextMenu);
  
  tray.on('double-click', () => {
    if (mainWindow) { mainWindow.show(); mainWindow.focus(); }
  });
}

// ============================================
// 3. IPC 통신 (렌더러 ↔ 메인 프로세스)
// ============================================

// 화면 보호 토글
ipcMain.handle('toggle-protection', (event, enabled) => {
  isContentProtected = enabled;
  if (mainWindow) mainWindow.setContentProtection(enabled);
  if (tray) createTray();
  return isContentProtected;
});

// 화면 보호 상태 조회
ipcMain.handle('get-protection-status', () => isContentProtected);

// 앱 정보
ipcMain.handle('get-app-info', () => ({
  version: app.getVersion(),
  name: app.getName(),
  platform: process.platform,
  arch: process.arch,
  electron: process.versions.electron,
  chrome: process.versions.chrome,
  node: process.versions.node,
  devMode: isDevMode
}));

// 알림 (크로스플랫폼)
ipcMain.handle('show-notification', (event, { title, body }) => {
  showCrossPlatformNotification(title, body);
});

// 클립보드 보호
ipcMain.handle('clear-clipboard', () => {
  clipboard.clear();
  return true;
});

// 녹화 프로세스 감지
ipcMain.handle('check-recording-processes', () => {
  return checkRecordingProcesses();
});

ipcMain.handle('start-recording-watch', () => {
  startRecordingWatch();
  return true;
});

ipcMain.handle('stop-recording-watch', () => {
  stopRecordingWatch();
  return true;
});

// [v1.4.0] 녹화 프로세스 강제 종료
ipcMain.handle('kill-recording-process', (event, processName) => {
  return killRecordingProcess(processName);
});

// [v1.5.0] 로컬 IP 주소 가져오기 (포렌식 워터마크용)
ipcMain.handle('get-local-ip', () => {
  try {
    const os = require('os');
    const interfaces = os.networkInterfaces();
    for (const name of Object.keys(interfaces)) {
      for (const iface of interfaces[name]) {
        if (iface.family === 'IPv4' && !iface.internal) {
          return iface.address;
        }
      }
    }
    return 'N/A';
  } catch (e) {
    return 'N/A';
  }
});

// ============================================
// [v1.3.0] 인앱 회의 IPC
// ============================================

ipcMain.handle('open-meeting-inapp', (event, url) => {
  const result = openMeetingInApp(url);
  return { success: !!result };
});

ipcMain.handle('close-meeting-inapp', () => {
  closeMeetingInApp();
  return { success: true };
});

ipcMain.handle('is-meeting-open', () => {
  return !!meetingView;
});

// [v1.3.1] 회의 뷰 표시/숨기기 (패널 전환 시)
ipcMain.handle('show-meeting-view', () => {
  if (meetingView && mainWindow) {
    mainWindow.addBrowserView(meetingView);
    updateMeetingViewBounds();
  }
  return true;
});

ipcMain.handle('hide-meeting-view', () => {
  if (meetingView && mainWindow) {
    mainWindow.removeBrowserView(meetingView);
  }
  return true;
});

// ============================================
// 4. 녹화 프로세스 능동 감지 + [v1.4.0] 블랙아웃 강화
// ============================================

const KNOWN_RECORDERS = {
  win32: [
    'obs64.exe', 'obs32.exe', 'obs.exe',
    'bdcam.exe', 'bdcamvk64.exe',
    'CamRecorder.exe',
    'ScreenRecorder.exe',
    'ShareX.exe',
    'oCam.exe',
    'GameBar.exe', 'GameBarPresenceWriter.exe',
    'ffmpeg.exe',
    'vlc.exe',
    'XSplit.Core.exe',
    'Streamlabs OBS.exe',
    'ScreenClippingHost.exe',
    // [v1.4.0] 추가 녹화 프로그램
    'Snagit32.exe', 'Snagit64.exe',
    'ScreenRec.exe',
    'Movavi Screen Recorder.exe',
    'Action.exe',
    'Icecream Screen Recorder.exe',
    'RecMaster.exe',
    'ApowerREC.exe',
    'Loom.exe',
    'Screencast-O-Matic.exe'
  ],
  darwin: [
    'QuickTime Player', 'screencaptureui', 'ScreenFlow',
    'OBS', 'obs', 'ffmpeg', 'vlc', 'Camtasia'
  ],
  linux: [
    'obs', 'ffmpeg', 'vlc', 'simplescreenrecorder',
    'kazam', 'vokoscreen', 'recordmydesktop'
  ]
};

function checkRecordingProcesses() {
  const platform = process.platform;
  const recorders = KNOWN_RECORDERS[platform] || [];
  const detected = [];

  try {
    let processList = '';
    if (platform === 'win32') {
      processList = execSync('tasklist /FO CSV /NH', { encoding: 'utf-8', timeout: 5000 });
    } else {
      processList = execSync('ps -eo comm', { encoding: 'utf-8', timeout: 5000 });
    }

    const listLower = processList.toLowerCase();
    recorders.forEach(name => {
      if (listLower.includes(name.toLowerCase())) {
        detected.push(name);
      }
    });
  } catch (e) {
    // 프로세스 목록 조회 실패 시 무시
  }

  return detected;
}

// [v1.4.0] 녹화 프로세스 강제 종료
function killRecordingProcess(processName) {
  try {
    if (process.platform === 'win32') {
      execSync(`taskkill /F /IM "${processName}"`, { encoding: 'utf-8', timeout: 5000 });
    } else if (process.platform === 'darwin' || process.platform === 'linux') {
      execSync(`pkill -f "${processName}"`, { encoding: 'utf-8', timeout: 5000 });
    }
    return { success: true, message: `${processName} 종료됨` };
  } catch (e) {
    return { success: false, message: `${processName} 종료 실패: ${e.message}` };
  }
}

function startRecordingWatch() {
  if (recordingCheckInterval) return;
  recordingCheckInterval = setInterval(() => {
    const detected = checkRecordingProcesses();
    if (detected.length > 0 && mainWindow) {
      // [v1.4.0] 녹화 감지 시 블랙아웃 명령 + 프로세스 목록 전송
      mainWindow.webContents.send('recording-detected', detected);
      // [v1.4.0] 블랙아웃 자동 활성화 명령
      mainWindow.webContents.send('activate-blackout', detected);
      showCrossPlatformNotification(
        '⚠️ VIDLOCK 경고',
        `녹화 프로그램 감지: ${detected.join(', ')}\n화면이 자동으로 보호됩니다.`
      );
    } else if (detected.length === 0 && mainWindow) {
      // [v1.4.0] 녹화 프로세스가 없으면 블랙아웃 해제
      mainWindow.webContents.send('deactivate-blackout');
    }
  }, 3000); // [v1.4.0] 감지 주기를 5초 → 3초로 단축
}

function stopRecordingWatch() {
  if (recordingCheckInterval) {
    clearInterval(recordingCheckInterval);
    recordingCheckInterval = null;
  }
}

// ============================================
// 5. 앱 이벤트
// ============================================

app.whenReady().then(() => {
  // [v1.4.0] 한국어 메뉴바 적용
  createKoreanMenu();
  
  createMainWindow();
  createTray();
  startRecordingWatch();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createMainWindow();
    else if (mainWindow) { mainWindow.show(); mainWindow.focus(); }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    // Windows/Linux: 트레이로 유지
  }
});

app.on('before-quit', () => {
  app.isQuitting = true;
  stopRecordingWatch();
  if (meetingView) closeMeetingInApp();
});

// ---- 보안: 새 창 열기 제어 (메인 창) ----
app.on('web-contents-created', (event, contents) => {
  if (mainWindow && contents.id === mainWindow.webContents.id) {
    contents.setWindowOpenHandler(({ url }) => {
      if (isMeetingURL(url)) {
        openMeetingInApp(url);
        return { action: 'deny' };
      }
      require('electron').shell.openExternal(url);
      return { action: 'deny' };
    });
  }
});

// ---- 두 번째 인스턴스 시도 시 기존 창 포커스 ----
app.on('second-instance', () => {
  if (mainWindow) {
    if (mainWindow.isMinimized()) mainWindow.restore();
    mainWindow.show();
    mainWindow.focus();
  }
});
