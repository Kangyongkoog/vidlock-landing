/**
 * VIDLOCK Desktop - Preload Script v1.4.0
 * © 2026 VIDLOCK. All Rights Reserved.
 * 
 * 렌더러 프로세스와 메인 프로세스 간 안전한 브릿지
 * [v1.3.0] 인앱 회의 BrowserView API 추가 + 화면 공유 지원
 * [v1.4.0] 녹화 감지 블랙아웃 + 프로세스 강제 종료 API 추가
 */

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('vidlockAPI', {
  // ---- 화면 보호 제어 ----
  toggleProtection: (enabled) => ipcRenderer.invoke('toggle-protection', enabled),
  getProtectionStatus: () => ipcRenderer.invoke('get-protection-status'),
  
  onProtectionChanged: (callback) => {
    const handler = (event, status) => callback(status);
    ipcRenderer.on('protection-changed', handler);
    return () => ipcRenderer.removeListener('protection-changed', handler);
  },
  
  // ---- 앱 정보 ----
  getAppInfo: () => ipcRenderer.invoke('get-app-info'),
  
  // ---- 시스템 알림 ----
  showNotification: (title, body) => ipcRenderer.invoke('show-notification', { title, body }),
  
  // ---- 클립보드 보호 ----
  clearClipboard: () => ipcRenderer.invoke('clear-clipboard'),
  
  // ---- [v1.5.0] 로컬 IP 주소 (포렌식 워터마크용) ----
  getLocalIP: () => ipcRenderer.invoke('get-local-ip'),
  
  // ---- 녹화 프로세스 감지 ----
  checkRecordingProcesses: () => ipcRenderer.invoke('check-recording-processes'),
  startRecordingWatch: () => ipcRenderer.invoke('start-recording-watch'),
  stopRecordingWatch: () => ipcRenderer.invoke('stop-recording-watch'),
  
  onRecordingDetected: (callback) => {
    const handler = (event, processes) => callback(processes);
    ipcRenderer.on('recording-detected', handler);
    return () => ipcRenderer.removeListener('recording-detected', handler);
  },
  
  // ---- [v1.4.0] 녹화 감지 블랙아웃 이벤트 ----
  onActivateBlackout: (callback) => {
    const handler = (event, processes) => callback(processes);
    ipcRenderer.on('activate-blackout', handler);
    return () => ipcRenderer.removeListener('activate-blackout', handler);
  },
  
  onDeactivateBlackout: (callback) => {
    const handler = () => callback();
    ipcRenderer.on('deactivate-blackout', handler);
    return () => ipcRenderer.removeListener('deactivate-blackout', handler);
  },
  
  // ---- [v1.4.0] 녹화 프로세스 강제 종료 ----
  killRecordingProcess: (processName) => ipcRenderer.invoke('kill-recording-process', processName),
  
  // ---- [v1.3.0] 인앱 회의 (BrowserView 임베딩) ----
  openMeetingInApp: (url) => ipcRenderer.invoke('open-meeting-inapp', url),
  closeMeetingInApp: () => ipcRenderer.invoke('close-meeting-inapp'),
  isMeetingOpen: () => ipcRenderer.invoke('is-meeting-open'),
  showMeetingView: () => ipcRenderer.invoke('show-meeting-view'),
  hideMeetingView: () => ipcRenderer.invoke('hide-meeting-view'),
  
  // 회의 이벤트
  onMeetingOpened: (callback) => {
    const handler = (event, url) => callback(url);
    ipcRenderer.on('meeting-opened', handler);
    return () => ipcRenderer.removeListener('meeting-opened', handler);
  },
  onMeetingClosed: (callback) => {
    const handler = () => callback();
    ipcRenderer.on('meeting-closed', handler);
    return () => ipcRenderer.removeListener('meeting-closed', handler);
  },
  
  // ---- 플랫폼 정보 ----
  platform: process.platform,
  isElectron: true
});
