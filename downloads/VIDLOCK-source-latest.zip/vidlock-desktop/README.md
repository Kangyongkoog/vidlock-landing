# VIDLOCK Desktop v1.6.1 (호스트용)

**Zoom 화상회의 실시간 녹화 방지 보안 솔루션 — 호스트(회의 주최자)용 앱**

© 2026 VIDLOCK (와풀 AI 교육연구소, 강용국). All Rights Reserved.

---

## 빠른 시작 (Quick Start)

```bash
# 1. 의존성 설치
npm install

# 2. 앱 실행
npm start

# 개발 모드 (DevTools 활성화)
npm run dev
```

> **요구 사항:** Node.js 18+ 및 npm 설치 필요

---

## 프로젝트 구조

```
vidlock-desktop/
├── src/
│   ├── main.js          # Electron 메인 프로세스 (핵심 로직)
│   ├── preload.js       # contextBridge IPC 브릿지
│   └── index.html       # 렌더러 UI (호스트 대시보드)
├── build/               # 빌드 리소스 (아이콘, 서명 설정)
│   ├── icon.png / icon.ico / icon.icns
│   ├── tray-icon.png
│   ├── icons/           # 멀티 사이즈 아이콘
│   └── entitlements.mac.plist
├── assets/              # 추가 리소스
├── docs/
│   └── BM_PATENT_DESKTOP.md  # 비즈니스 모델 특허 문서
├── legal/
│   └── LICENSE_KO.txt
├── package.json
├── LICENSE.md
└── README.md            # (이 파일)
```

---

## 주요 기능

| 기능 | 설명 |
|------|------|
| OS 레벨 녹화 차단 | `setContentProtection(true)` — 화면 녹화 시 검은 화면 |
| AI 카메라 감지 | TensorFlow.js COCO-SSD로 핸드폰/카메라 촬영 감지 |
| Zoom 회의 관리 | 회의 링크 등록, 참가자 접속 모니터링 |
| 포렌식 워터마크 | 투명 사용자 ID/시간 삽입 |
| 녹화 프로세스 감지 | OBS, oCam, 반디캠 등 프로세스 탐지 |
| 실시간 알림 | 참가자 녹화 시도 시 호스트에게 즉시 알림 |
| 시스템 트레이 상주 | 백그라운드 실행, 트레이 아이콘 메뉴 |

---

## 빌드 (배포용 설치 파일 생성)

```bash
# Windows 설치 파일 (.exe)
npm run build:win

# macOS 설치 파일 (.dmg)
npm run build:mac

# Linux 설치 파일 (.AppImage)
npm run build:linux

# 전체 플랫폼
npm run build:all
```

빌드 결과물은 `dist/` 폴더에 생성됩니다.

---

## 참가자용 앱과의 관계

- **호스트용 (이 앱):** 회의 생성/관리, 참가자 모니터링, 녹화 시도 알림 수신
- **참가자용 (vidlock-participant):** 참가자 PC에서 녹화 감지 및 화면 보호 실행

호스트가 Zoom 회의를 VIDLOCK에 등록하면, 참가자는 참가자용 앱을 통해 안전하게 회의에 참여합니다.

---

## 법적 보호

- 저작권 등록: 한국저작권위원회 (2026-020961)
- 영업비밀: 영업비밀보호센터 원본증명 완료
- 상표 출원: VIDLOCK (사건번호 40-2026-0083610, 제09류)
- 발명일: 2026년 4월 6일

---

## 연락처

- Email: kangyg0612@naver.com
